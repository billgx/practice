
console.log('Wolf Man vs. Deadite......FIGHT!');
class WolfMan {
    constructor() {
      this.health = 100;
      this.sound = "Wolf Man howels: AAAAAAWWWWOOOOOOOOOOOOO!!! GRRRRRRR!!";
      console.log('Wolf Man Health: '+this.health);
      this.damage = 18;
      console.log (this.sound);
    }
  }


  
  class Deadite {
    constructor() {
        this.health = 125;
        this.damage = 11;
        console.log('Deadite Health: '+this.health);
        this.sound = "Deadite says: I'LL SWALLOW YOUR SOUL!!!!"
        console.log (this.sound);
    }
}

class Dice {
    constructor() {

    }

    rollDice() {
        
        this.face = Math.floor(Math.random() * 20) + 1; // randomly get number 1-6
        console.log ("rolling dice: " + "a " + this.face + "!");
        return this.face;
    }
}

//create the monsters
let deadite = new Deadite();
let  wolfman = new WolfMan();
let cDice = new Dice();
let sDice = new Dice();

    
function fightMonsters(m1, m2) {
    // function to create the monsters who will fight
    // passing in two monster objects as parameters

    let monster1 = m1;
    monster1.name = "Wolf Man";
    let monster2 = m2;
    monster2.name = "Deadite";

    let m1Roll = cDice.rollDice();
    let m2Roll = sDice.rollDice();

    while (deadite.health >=1 && wolfman.health >=1){

        m1Roll = cDice.rollDice();
     m2Roll = sDice.rollDice();

    if (m1Roll === m2Roll ) {
        console.log("it's a tie, roll again.")
    } else if (m1Roll > m2Roll) {
        deadite.health += -1 * wolfman.damage
        console.log(monster1.name + " Struck Deadite! "); 
        console.log('DEADITE Current Health: '+ deadite.health)
        console.log('WOLF MAN Current Health: ' + wolfman.health)
    } else {
        console.log(monster2.name + " Smacked Wolf Man! ")
        wolfman.health += -1 * deadite.damage
        console.log('DEADITE Current Health: '+ deadite.health)
        console.log('WOLF MAN Current Health: ' + wolfman.health)
    } if (deadite.health <=0) {
        console.log('DEADITE Current Health: '+ deadite.health)
console.log('WOLF MAN Current Health: ' + wolfman.health)
    console.log(monster2.name + ' Has Been Vanquished! Wolf Man Wins!!!')
    }
} if (wolfman.health <=0) {
    console.log(monster1.name + ' Has Been Slain! Deadite Wins!!!')
    }
}




fightMonsters(deadite, wolfman);