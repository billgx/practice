//class Monster ()
//  constructor()(
//    this.name = "")
//   this.alive = true;
//  )
//  growl()(
//    console.log("Monster says:" + this.sound);
//  )
//)


class Peter_Griffin { //extends Monster{
    constructor(){
      this.health= 150; //total health
      this.sound="NHEHEHEHEHE";
      this.damage= 7; //unused at this point
      this.speed= 6; //also max attack power
      //console.log ("Peter Griffin has entered our universe")
    }
  }

class Giant_Chicken { //extends Monster{
    constructor(){
      this.health= 100;
      this.sound="BUKAHHH";
      this.damage= 8; //unused
      this.speed= 7; //also max attack power
      //console.log ("Chicken has delivered")
    }
  }


function rolldicePeter (){
  var PDice = (Math.random() * Peter.speed);
  return(PDice)
}

function rolldiceChicken (){
  var CDice = (Math.random() * Chicken.speed);
  return(CDice)
}


let Peter = new Peter_Griffin; //Inituallize new peter and chicken every time the browser reloads
let Chicken = new Giant_Chicken;
  

function fight(){
  let PAttack = rolldicePeter();
  let CAttack = rolldiceChicken();
  //console.log(CAttack - PAttack)
    
  if (CAttack > PAttack) { //chickens speed wins
    document.getElementById("FightStatus").innerHTML = 'Chicken Attacks for ' + Math.round(CAttack) + ' damage!'
    Peter.health = (Peter.health - CAttack)

    document.getElementById("fightpicture").innerHTML = "<img src='chickenattack.jpg' width='200px' height='200px'>";
   //console.log('Peter Health: ' + Peter.health)
  }
    
  if (PAttack > CAttack) { //Peters speed wins
   document.getElementById("FightStatus").innerHTML = 'Peter Attacks for ' + Math.round(PAttack) + ' damage!'
    Chicken.health = (Chicken.health - PAttack)
   //console.log('Chicken Health: ' + Chicken.health)
    
    document.getElementById("fightpicture").innerHTML = "<img src='peterattack.png' width='200px' height='200px'>";
  }
  
  document.getElementById("PeterHealth").innerHTML= "Peter Griffin Health: " + Math.round(Peter.health);
    document.getElementById("ChickenHealth").innerHTML= "Giant Chicken Health: " + Math.round(Chicken.health);

  
//var intervalId = window.setInterval(function(){ //runs fight() every so many seconds
//  fight()
//}, 1000);

//win conditions (need to freeze game or make win screen)
  if (Peter.health < 0) { //Peter death
   console.log ('Peter has fallen')
   document.getElementById("FightStatus").innerHTML = 'Giant Chicken Wins!'
  //clearInterval(intervalId); //Should stop loop, but doesn't
    document.getElementById("PeterHealth").innerHTML= 'Peter Griffin Health: Dead';
    Peter.speed=0 //ensures Peter cannot attack post death
  }

  if (Chicken.health < 0) { //Chicken death
   console.log ('The Chicken has been cooked')
  document.getElementById("FightStatus").innerHTML = 'Peter Griffin Wins!'
  // clearInterval(intervalId); //Should stop loop, but doesn't
    document.getElementById("ChickenHealth").innerHTML='Giant Chicken Health: Dead';
    Chicken.speed=0 //ensures chicken cannot attack post death
  }
  }